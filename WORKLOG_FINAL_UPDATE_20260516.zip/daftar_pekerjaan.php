<?php
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';

// handle form submission
require_app('config/database.php');
require_app('functions/helpers.php');

// Detect Protocol for Base URL (for Google Viewer)
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
$baseUrl = $protocol . $_SERVER['HTTP_HOST'] . rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
?>

<!-- Document Viewer Modal -->
<div class="modal fade" id="docViewerModal" tabindex="-1" aria-hidden="true" style="z-index: 2000;">
    <div class="modal-dialog modal-fullscreen">
        <div class="modal-content border-0" style="border-radius: 0;">
            <div class="modal-header bg-dark text-white border-0 py-2">
                <h6 class="modal-title small fw-bold" id="docViewerTitle">Pratinjau Dokumen</h6>
                <div class="d-flex gap-2">
                    <a href="#" id="btnDownloadActual" class="btn btn-sm btn-outline-light rounded-pill px-3" target="_blank">
                        <i class="bi bi-download me-1"></i> Download
                    </a>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
            </div>
            <div class="modal-body p-0 bg-secondary d-flex justify-content-center align-items-center">
                <div id="docLoader" class="text-white text-center position-absolute">
                    <div class="spinner-border" role="status"></div>
                    <div class="mt-2 small">Memuat Dokumen...</div>
                </div>
                <iframe id="docViewerIframe" src="" width="100%" height="100%" style="border:none; background: #fff;" onload="document.getElementById('docLoader').classList.add('d-none')"></iframe>
            </div>
        </div>
    </div>
</div>

ensure_session_started();
$npp = $_SESSION['npp'] ?? null;
$nama_emp = $_SESSION['nama_emp'] ?? null;

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $roleName = function_exists('get_current_role_name') ? get_current_role_name($conn ?? null) : null;
    $isManager = function_exists('role_is') ? role_is($roleName, 'manager') : (strtolower((string) $roleName) === 'manager');
    if (!$isManager) {
        $errors[] = 'Hanya role manager yang dapat membuat pekerjaan baru.';
    }

    $judul = trim($_POST['judul'] ?? '');
    $deskripsi = trim($_POST['deskripsi'] ?? '');
    $tglMulai = trim($_POST['tgl_mulai'] ?? '');
    $tglSelesai = trim($_POST['tgl_selesai'] ?? '');
    $assigned_to_npp = trim($_POST['assigned_to_npp'] ?? $_POST['ditugaskan'] ?? '');
    $master_tugas_id = trim($_POST['master_tugas_id'] ?? '');
    $periode = trim($_POST['periode'] ?? '');

    if ($judul === '')
        $errors[] = 'Judul pekerjaan wajib diisi';
    if ($deskripsi === '')
        $errors[] = 'Deskripsi pekerjaan wajib diisi';
    if ($tglMulai === '')
        $errors[] = 'Tanggal mulai wajib diisi';
    if ($tglSelesai === '')
        $errors[] = 'Tanggal selesai wajib diisi';
    if ($assigned_to_npp === '')
        $errors[] = 'Pilih pegawai yang ditugaskan';


    if (empty($errors) && isset($conn)) {
        $stmt = $conn->prepare("INSERT INTO pekerjaan (judul, deskripsi, created_by_npp, nama_emp, tgl_mulai, tgl_selesai, assigned_to_npp, master_tugas_id, periode) VALUES (?, ?, ?, ?, NULLIF(?, ''), NULLIF(?, ''), ?, NULLIF(?,''), NULLIF(?,''))");
        if ($stmt) {
            $stmt->bind_param('sssssssss', $judul, $deskripsi, $npp, $nama_emp, $tglMulai, $tglSelesai, $assigned_to_npp, $master_tugas_id, $periode);
            $stmt->execute();
            $stmt->close();
            if (function_exists('flash_swal'))
                flash_swal('success', 'Tersimpan', 'Pekerjaan berhasil ditambahkan');
            header('Location: ' . site_url('daftar_pekerjaan.php'));
            exit;
        } else {
            $errors[] = 'Gagal menyiapkan penyimpanan.';
        }
    } else if (!isset($conn)) {
        $errors[] = 'Koneksi database tidak tersedia.';
    }
}

// fetch recent entries
$rows = [];
if (isset($conn)) {
    $res = $conn->query("SELECT * FROM pekerjaan ORDER BY created_at DESC LIMIT 50");
    if ($res) {
        while ($r = $res->fetch_assoc())
            $rows[] = $r;
        $res->free();
    }
}

// fetch employees for assignee selection
$employees = [];
if (isset($conn)) {
    $nama_bagian = $_SESSION['nama_bagian'] ?? null;
    if (!empty($nama_bagian)) {
        $stmt = $conn->prepare("SELECT npp, nama_emp FROM employee WHERE nama_bagian = ? ORDER BY nama_emp ASC");
        if ($stmt) {
            $stmt->bind_param('s', $nama_bagian);
            $stmt->execute();
            $res = $stmt->get_result();
            if ($res) {
                while ($e = $res->fetch_assoc())
                    $employees[] = $e;
                $res->free();
            }
            $stmt->close();
        }
    } else {
        $r2 = $conn->query("SELECT npp, nama_emp FROM employee ORDER BY nama_emp ASC");
        if ($r2) {
            while ($e = $r2->fetch_assoc())
                $employees[] = $e;
            $r2->free();
        }
    }
}

// load master tasks for optional linkage (include fields for auto-fill)
$master_tasks = [];
if (isset($conn)) {
    $rm = $conn->query('SELECT mt.id, mt.judul, mt.deskripsi, mt.npp, mt.bagian_id, mt.periode, e.nama_emp AS assigned_name FROM master_tugas mt LEFT JOIN employee e ON e.npp = mt.npp ORDER BY mt.judul');
    if ($rm) {
        while ($mt = $rm->fetch_assoc())
            $master_tasks[] = $mt;
        $rm->free();
    }
}

?>

<div class="app-main">
    <div class="app-content p-2 p-md-4">
        <div class="container-fluid px-0 px-md-2">
            <h3 class="mb-3 px-2">Pengisian Daftar Pekerjaan</h3>

            <div class="card mb-4 border-0 shadow-sm card-calendar">
                <div class="card-body p-2 p-md-4">
                    <div id="calendar" class="calendar-wrap"></div>
                </div>
            </div>

            <style>
                /* Fluid Layout & Flexible Images */
                img {
                    max-width: 100%;
                    height: auto;
                }

                /* iOS-Style Calendar UI - ENHANCED SIZE */
                #calendar {
                    background: #fff;
                    border-radius: 1.25rem;
                    padding: 0.625rem;
                    border: none;
                }

                .card-calendar {
                    border-radius: 1.5rem;
                    width: 100%;
                }

                .card-calendar .calendar-wrap {
                    width: 100%;
                    min-height: 56.25rem;
                    /* 900px = 56.25rem */
                }

                /* Toolbar Styling */
                .fc .fc-toolbar-title {
                    font-weight: 700;
                    color: #1c1c1e;
                    font-size: 1.8rem !important;
                }

                .fc .fc-button-primary {
                    background: #f2f2f7;
                    border: none;
                    color: #007aff;
                    border-radius: 0.75rem;
                    padding: 0.625rem 1.25rem;
                    font-weight: 700;
                    font-size: 1rem;
                    transition: all 0.2s;
                }

                .fc .fc-button-primary:hover {
                    background: #e5e5ea;
                }

                .fc .fc-button-active {
                    background: #007aff !important;
                    color: #fff !important;
                }

                /* DayGrid Styling */
                .fc .fc-theme-standard td,
                .fc .fc-theme-standard th {
                    border-color: #f2f2f7;
                }

                .fc .fc-daygrid-day-number {
                    color: #8e8e93;
                    font-weight: 700;
                    padding: 0.75rem;
                    font-size: 1.1rem;
                }

                .fc .fc-col-header-cell-cushion {
                    color: #8e8e93;
                    font-size: 0.9rem;
                    text-transform: uppercase;
                    letter-spacing: 0.0625rem;
                    padding: 0.9375rem;
                    font-weight: 700;
                }

                /* Custom Event Card (iOS Style - STATUS BAR MODE) */
                .fc-custom-event {
                    padding: 0.5rem 1rem;
                    border-radius: 2rem; /* Pill style */
                    margin: 0.3rem 0.5rem;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    transition: all 0.2s;
                    cursor: pointer;
                    border-left: 0.5rem solid !important;
                    width: auto !important;
                    min-height: 1.75rem; /* Ensure it stays visible without text */
                    box-shadow: 0 0.125rem 0.4rem rgba(0,0,0,0.06);
                }
                .fc-custom-event:hover { filter: brightness(0.94); transform: scale(1.02); box-shadow: 0 0.3rem 0.8rem rgba(0,0,0,0.1); }
                
                .fc-ce-title {
                    display: none; /* Hide title as requested */
                }

                /* Category Colors (Subtle Fill + Strong Left Border) */
                .ev-harian {
                    background: #e8f5e9 !important;
                    border-color: #4caf50 !important;
                }

                .ev-mingguan {
                    background: #fffde7 !important;
                    border-color: #fbc02d !important;
                }

                .ev-bulanan {
                    background: #e3f2fd !important;
                    border-color: #2196f3 !important;
                }

                .ev-triwulan {
                    background: #fff3e0 !important;
                    border-color: #ff9800 !important;
                }

                .ev-manual {
                    background: #f5f5f5 !important;
                    border-color: #9e9e9e !important;
                }

                .ev-revisi {
                    background: #ffebee !important;
                    border-color: #f44336 !important;
                    color: #b71c1c !important;
                }


                /* FullCalendar Reset & Expansion */
                .fc-daygrid-event {
                    background: transparent !important;
                    border: none !important;
                    box-shadow: none !important;
                }

                .fc-daygrid-event-h-harness {
                    margin-bottom: 0.375rem !important;
                }

                .fc .fc-daygrid-day-frame {
                    min-height: 11.25rem !important;
                }

                /* Modal Styling - App Style */
                .modal-content {
                    border-radius: 1.75rem;
                    border: none;
                    box-shadow: 0 1.5625rem 3.125rem -0.75rem rgba(0, 0, 0, 0.2);
                }

                .modal-header {
                    border-bottom: 0.0625rem solid #f2f2f7;
                    padding: 1.25rem 1.5rem;
                }

                .modal-footer {
                    border-top: none;
                    padding: 0.75rem 1.5rem 1.5rem;
                    gap: 0.75rem;
                }

                .btn-app-primary {
                    background: linear-gradient(135deg, #007aff 0%, #0056b3 100%);
                    color: #fff;
                    border: none;
                    border-radius: 1rem;
                    padding: 0.875rem 1.75rem;
                    font-weight: 700;
                    transition: all 0.3s;
                    box-shadow: 0 0.25rem 0.75rem rgba(0, 122, 255, 0.3);
                }

                .btn-app-secondary {
                    background: #f2f2f7;
                    color: #1c1c1e;
                    border: none;
                    border-radius: 1rem;
                    padding: 0.875rem 1.75rem;
                    font-weight: 600;
                    transition: all 0.2s;
                }

                .btn-app-primary:hover {
                    transform: translateY(-0.125rem);
                    box-shadow: 0 0.375rem 1.25rem rgba(0, 122, 255, 0.4);
                }

                .btn-app-secondary:hover {
                    background: #e5e5ea;
                }

                /* Floating Action Button (FAB) */
                .fab-add {
                    position: fixed;
                    bottom: 1.875rem;
                    right: 1.5625rem;
                    width: 4rem;
                    height: 4rem;
                    border-radius: 50%;
                    background: linear-gradient(135deg, #007aff 0%, #0056b3 100%);
                    color: #fff;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    font-size: 1.75rem;
                    border: none;
                    box-shadow: 0 0.5rem 1.5625rem rgba(0, 122, 255, 0.5);
                    z-index: 1050;
                    transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
                }

                .fab-add:hover {
                    transform: scale(1.1) rotate(90deg);
                }

                .fab-add:active {
                    transform: scale(0.9);
                }

                @media (max-width:575.98px) {
                    .fc .fc-toolbar {
                        flex-direction: column !important;
                        gap: 1rem !important;
                        align-items: center !important;
                    }

                    .fc .fc-toolbar-title {
                        font-size: 1.1rem !important;
                        order: -1;
                        width: 100%;
                        text-align: center;
                        margin: 0 !important;
                    }

                    .fc .fc-toolbar-chunk {
                        display: flex;
                        flex-wrap: wrap;
                        justify-content: center;
                        gap: 0.3rem;
                        width: 100%;
                    }

                    .fc-button {
                        padding: 0.5rem 0.6rem !important;
                        font-size: 0.75rem !important;
                        border-radius: 8px !important;
                        flex: 1 1 auto;
                    }

                    .fc-addPekerjaan-button {
                        display: none !important;
                    }

                    .fc-custom-event {
                        padding: 0.4rem 0.5rem !important;
                        border-radius: 2rem !important; /* Keep pill style on mobile */
                        min-height: 1.5rem !important;
                    }

                    .fc .fc-daygrid-day-frame {
                        min-height: 6.25rem !important;
                    }

                    /* Mobile Footer Buttons */
                    .modal-footer {
                        flex-direction: column-reverse;
                        padding: 1.25rem;
                    }

                    .modal-footer .btn {
                        width: 100%;
                        margin: 0 !important;
                    }
                }
            </style>
            <script>
                var currentUserNpp = '<?php echo e($npp ?? ''); ?>';
                window.addEventListener('load', function () {
                    var el = document.getElementById('calendar');
                    if (!el || !window.FullCalendar) {
                        console.warn('Calendar element or FullCalendar is not available.');
                        return;
                    }

                    var viewportWidth = window.innerWidth || document.documentElement.clientWidth;
                    var isMobile = viewportWidth < 576; 

                    var initialViewMode = isMobile ? 'listWeek' : 'dayGridMonth';
                    var hLeft = isMobile ? 'prev,next today filterRevisi' : 'prev,next today addPekerjaan filterRevisi';
                    var hRight = isMobile ? 'listWeek,dayGridMonth' : 'dayGridMonth,timeGridWeek,listWeek';
                    var initialDate = new Date().toISOString().split('T')[0];

                    function showEventDetail(ev) {

                        function escapeHtml(s) {
                            return String(s ?? '')
                                .replace(/&/g, '&amp;')
                                .replace(/</g, '&lt;')
                                .replace(/>/g, '&gt;')
                                .replace(/"/g, '&quot;')
                                .replace(/'/g, '&#039;');
                        }

                        var props = ev.extendedProps || {};
                        var desc = props.description || '';
                        var status = props.status || '';
                        var assigned = props.ditugaskan || '';
                        var assignedName = props.assigned_name || '';
                        var reporter = props.reporter_name || 'Manager';
                        var tglMulai = props.tgl_mulai || ev.startStr || '';
                        var tglSelesai = props.tgl_selesai || '';
                        var doneAt = props.done_at || '';

                        var assignedLabel = assignedName ? (assignedName + ' (' + assigned + ')') : (assigned || '-');
                        var reporterLabel = reporter;

                        var mulaiText = tglMulai;
                        var selesaiText = tglSelesai;
                        var tanggalText = tglSelesai ? (mulaiText + ' — ' + selesaiText) : mulaiText;

                        var titleEl = document.getElementById('pj_detail_title');
                        var tanggalEl = document.getElementById('pj_detail_tanggal');
                        var statusEl = document.getElementById('pj_detail_status');
                        var assignedEl = document.getElementById('pj_detail_assigned');
                        var reporterEl = document.getElementById('pj_detail_reporter');
                        var descEl = document.getElementById('pj_detail_desc');
                        var doneAtEl = document.getElementById('pj_detail_done_at');
                        var doneRow = document.getElementById('pj_detail_done_row');
                        var alertEl = document.getElementById('pj_detail_alert');
                        var doneBtn = document.getElementById('pj_detail_done');

                        var rawTitle = ev.title || '';
                        var cleanTitle = rawTitle.replace(/^\[.*?\]\s*/, '');
                        if (titleEl) titleEl.textContent = cleanTitle;
                        if (tanggalEl) tanggalEl.textContent = tanggalText;

                        var statusText = status ? status : '-';
                        if (statusEl) {
                            statusEl.textContent = statusText;
                            statusEl.classList.remove('text-bg-secondary', 'text-bg-primary', 'text-bg-success', 'text-bg-danger');
                            if (status === 'done') statusEl.classList.add('text-bg-success');
                            else if (status === 'revisi') statusEl.classList.add('text-bg-danger');
                            else if (status && status !== '-') statusEl.classList.add('text-bg-primary');
                            else statusEl.classList.add('text-bg-secondary');
                        }

                        if (assignedEl) assignedEl.textContent = assignedLabel;
                        if (reporterEl) reporterEl.textContent = reporterLabel;
                        if (descEl) descEl.innerHTML = desc ? escapeHtml(desc).replace(/\n/g, '<br>') : '<span class="text-body-secondary">-</span>';

                        if (alertEl) {
                            alertEl.classList.add('d-none');
                            alertEl.classList.remove('alert-success', 'alert-danger', 'alert-warning');
                            alertEl.textContent = '';

                            // Tampilkan Catatan Revisi jika status = revisi
                            if (status === 'revisi' && props.catatan_revisi) {
                                alertEl.classList.remove('d-none');
                                alertEl.classList.add('alert-danger');
                                alertEl.innerHTML = `<strong><i class="bi bi-exclamation-octagon-fill me-2"></i> PERLU REVISI:</strong><br>${props.catatan_revisi}`;
                            }
                        }

                        var isMaster = !!props.is_master;
                        var canDone = currentUserNpp && assigned && assigned === currentUserNpp && status !== 'done';
                        // status 'revisi' juga diperbolehkan untuk Tandai Selesai ulang
                        if (doneBtn) {
                            doneBtn.dataset.id = ev.id;
                            doneBtn.dataset.isMaster = '0';
                            doneBtn.dataset.masterId = '';
                            doneBtn.dataset.occDate = '';
                            doneBtn.dataset.occToken = '';

                            if (isMaster) {
                                doneBtn.dataset.isMaster = '1';
                                doneBtn.dataset.masterId = (props.master_tugas_id != null) ? String(props.master_tugas_id) : '';
                                doneBtn.dataset.occDate = props.tgl_mulai || ev.startStr || '';
                                doneBtn.dataset.occToken = props.occ_token || '';
                            }

                            doneBtn.disabled = false;
                            doneBtn.classList.toggle('d-none', !canDone);
                        }

                        if (doneRow && doneAtEl) {
                            if (status === 'done' && doneAt) {
                                doneAtEl.textContent = doneAt;
                                doneRow.classList.remove('d-none');
                            } else {
                                doneAtEl.textContent = '-';
                                doneRow.classList.add('d-none');
                            }
                        }

                        var uploadRow = document.getElementById('pj_detail_upload_row');
                        var fileInput = document.getElementById('pj_detail_file');
                        var fileView = document.getElementById('pj_detail_file_view');
                        var fileLink = document.getElementById('pj_detail_file_link');

                        if (uploadRow) {
                            uploadRow.classList.remove('d-none');
                            if (status === 'done') {
                                if (fileInput) fileInput.classList.add('d-none');
                                if (props.lampiran) {
                                    fileView.classList.remove('d-none');
                                    fileLink.href = '<?php echo base_path(); ?>/uploads/' + props.lampiran;
                                    fileLink.innerHTML = 'Lihat Lampiran Bukti';
                                    fileLink.className = 'btn btn-xs btn-outline-info';
                                } else {
                                    fileView.classList.add('d-none');
                                }
                            } else if (status === 'revisi') {
                                if (fileInput) {
                                    fileInput.classList.remove('d-none');
                                    fileInput.value = '';
                                }
                                if (props.lampiran) {
                                    fileView.classList.remove('d-none');
                                    fileLink.innerHTML = '<i class="bi bi-file-earmark-x"></i> Dokumen Sebelumnya (Ditolak)';
                                    fileLink.className = 'btn btn-xs btn-outline-danger mt-2';
                                    fileLink.onclick = (e) => {
                                        e.preventDefault();
                                        viewDocument(props.lampiran, cleanTitle);
                                    };
                                } else {
                                    fileView.classList.add('d-none');
                                }
                            } else {
                                if (fileInput) {
                                    fileInput.classList.remove('d-none');
                                    fileInput.value = '';
                                }
                                fileView.classList.add('d-none');
                            }
                        }

                        if (window.openPekerjaanDetailModal) {
                            window.openPekerjaanDetailModal();
                        }
                    }

                    var calendar = new FullCalendar.Calendar(el, {
                        initialView: initialViewMode,
                        initialDate: initialDate,
                        customButtons: {
                            addPekerjaan: { text: 'Tambah Pekerjaan', click: function () { window.openPekerjaanModal(); } },
                            filterRevisi: {
                                text: 'Cek Revisi',
                                click: function (e) {
                                    var currentSrc = calendar.getEventSources()[0];
                                    if (!currentSrc) return;
                                    var isRevisiMode = currentSrc.url.includes('status=revisi');
                                    currentSrc.remove();

                                    if (isRevisiMode) {
                                        // Kembali ke mode normal (Bulan)
                                        calendar.changeView(isMobile ? 'listWeek' : 'dayGridMonth');
                                        calendar.addEventSource('<?php echo site_url("api/events_pekerjaan.php"); ?>?status=open');
                                        e.target.style.backgroundColor = '';
                                        e.target.style.color = '';
                                        e.target.innerHTML = 'Cek Revisi';
                                    } else {
                                        // MASUK KE MODE REVISI GLOBAL
                                        // Gunakan view listYear (jika tersedia) atau listWeek dengan range luas
                                        calendar.changeView('listYear');
                                        calendar.addEventSource('<?php echo site_url("api/events_pekerjaan.php"); ?>?status=revisi');

                                        e.target.style.backgroundColor = '#f44336';
                                        e.target.style.color = '#fff';
                                        e.target.innerHTML = '<i class="bi bi-arrow-left-circle-fill me-1"></i> Kembali';

                                        Swal.fire({
                                            icon: 'info',
                                            title: 'Daftar Revisi',
                                            text: 'Menampilkan seluruh tugas yang perlu diperbaiki dari semua periode.',
                                            timer: 2000,
                                            showConfirmButton: false,
                                            toast: true,
                                            position: 'top-end'
                                        });
                                    }
                                }
                            }
                        },
                        headerToolbar: { 
                            left: hLeft, 
                            center: 'title', 
                            right: hRight 
                        },
                        events: '<?php echo site_url("api/events_pekerjaan.php"); ?>?status=open',
                        displayEventTime: false,
                        height: 'auto',
                        expandRows: true,
                        dayMaxEventRows: isMobile ? 2 : 6,
                        locale: 'id',
                        displayEventEnd: true,
                        nextDayThreshold: '00:00:00',
                        buttonText: {
                            today: 'Hari ini',
                            month: 'Bulan',
                            week: 'Minggu',
                            list: 'Daftar'
                        },
                        navLinks: true,
                        stickyHeaderDates: true,
                        dateClick: function (info) {
                            if (typeof window.openPekerjaanModal === 'function') {
                                window.openPekerjaanModal(info.dateStr);
                            }
                        },
                        eventClick: function (info) { showEventDetail(info.event); },
                        eventContent: function (arg) {
                            var ev = arg.event;
                            var props = ev.extendedProps || {};
                            
                            // Tentukan warna
                            var periode = (props.periode || '').toLowerCase();
                            var statusVal = (props.status || '').toLowerCase();
                            
                            var dotColor = '#9e9e9e'; 
                            var colorClass = 'ev-manual';
                            
                            if (periode === 'harian') { dotColor = '#4caf50'; colorClass = 'ev-harian'; }
                            else if (periode === 'mingguan') { dotColor = '#fbc02d'; colorClass = 'ev-mingguan'; }
                            else if (periode === 'bulanan') { dotColor = '#2196f3'; colorClass = 'ev-bulanan'; }
                            else if (periode === 'triwulan') { dotColor = '#ff9800'; colorClass = 'ev-triwulan'; }
                            
                            if (statusVal === 'revisi') {
                                dotColor = '#f44336';
                                colorClass = 'ev-revisi';
                            }

                            // SMART UI: Jika tampilan BULAN di HP, gunakan DOT (Titik)
                            if (isMobile && arg.view.type === 'dayGridMonth') {
                                return {
                                    html: '<div style="display:flex; justify-content:center; padding: 2px 0;">' +
                                          '<div style="width:8px; height:8px; border-radius:50%; background-color:' + dotColor + '; box-shadow: 0 0 5px rgba(0,0,0,0.15);"></div>' +
                                          '</div>'
                                };
                            }
                            
                            // Tampilan STATUS BAR (Pill berwarna tanpa teks)
                            var html = '<div class="fc-custom-event ' + colorClass + '" title="' + (ev.title || '') + '"></div>';

                            return { html: html };
                        },
                        eventDidMount: function (info) {
                            try {
                                var btn = info.el.querySelector('.ec-open-btn');
                                if (btn) {
                                    btn.addEventListener('click', function (e) {
                                        e.stopPropagation();
                                        showEventDetail(info.event);
                                    });
                                }

                                // CSS tambahan agar kotak event kelanjutan tidak memiliki border kiri/kanan
                                // sehingga terlihat seperti satu kesatuan bar panjang
                                if (!info.isStart) {
                                    var customEventEl = info.el.querySelector('.fc-custom-event');
                                    if (customEventEl) {
                                        customEventEl.style.borderLeft = 'none';
                                        customEventEl.style.borderTopLeftRadius = '0';
                                        customEventEl.style.borderBottomLeftRadius = '0';
                                    }
                                }
                                if (!info.isEnd) {
                                    var customEventEl = info.el.querySelector('.fc-custom-event');
                                    if (customEventEl) {
                                        customEventEl.style.borderRight = 'none';
                                        customEventEl.style.borderTopRightRadius = '0';
                                        customEventEl.style.borderBottomRightRadius = '0';
                                    }
                                }

                            } catch (e) { console.error(e); }
                        },
                        views: {
                            dayGridMonth: { dayMaxEventRows: 3 },
                            listWeek: { noEventsMessage: 'Tidak ada pekerjaan minggu ini' }
                        },
                        eventDisplay: 'block'
                    });
                    calendar.render();
                    window.pekerjaanCalendar = calendar;

                    if (isMobile) el.classList.add('mobile-calendar');
                });
            </script>

            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0"><?php foreach ($errors as $err)
                        echo '<li>' . e($err) . '</li>'; ?></ul>
                </div>
            <?php endif; ?>

            <!-- Form removed: use calendar modal to create tasks -->

            <!-- Modal for creating pekerjaan -->
            <div class="modal fade" id="pekerjaanModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-lg modal-dialog-centered modal-fullscreen-sm-down">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Buat Pekerjaan</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form id="pekerjaanForm">
                                <div class="mb-3">
                                    <label class="form-label">Judul</label>
                                    <input name="judul" id="pj_judul" class="form-control form-control-lg" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Deskripsi</label>
                                    <textarea name="deskripsi" id="pj_deskripsi" class="form-control form-control-lg"
                                        rows="4" required></textarea>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Ditugaskan ke</label>
                                    <select name="assigned_to_npp" id="pj_ditugaskan" class="form-select form-select-lg"
                                        required>
                                        <option value="">-- Pilih Pegawai --</option>
                                        <?php foreach ($employees as $emp): ?>
                                            <option value="<?php echo e($emp['npp']); ?>"><?php echo e($emp['nama_emp']); ?>
                                                (<?php echo e($emp['npp']); ?>)</option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="row g-3">
                                    <div class="col-12 col-md-6">
                                        <label class="form-label">Tanggal Mulai</label>
                                        <input type="date" name="tgl_mulai" id="pj_mulai"
                                            class="form-control form-control-lg" required>
                                    </div>
                                    <div class="col-12 col-md-6">
                                        <label class="form-label">Tanggal Selesai</label>
                                        <input type="date" name="tgl_selesai" id="pj_selesai"
                                            class="form-control form-control-lg" required>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label hidden class="form-label">Periode (input manual)</label>
                                    <input hidden name="periode" id="pj_periode" class="form-control"
                                        placeholder="contoh: harian">
                                </div>
                                <!-- <div class="mb-3">
                                                <label class="form-label">Dilaporkan Oleh</label>
                                                <input class="form-control" value="<?php echo e($nama_emp ?? $npp ?? ''); ?>" disabled>
                                            </div> -->
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-app-secondary" data-bs-dismiss="modal">Batal</button>
                            <button type="button" id="pj_save" class="btn btn-app-primary px-5">Simpan
                                Pekerjaan</button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Modal detail pekerjaan (custom, mirip task app) -->
            <div class="modal fade" id="pekerjaanDetailModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-lg modal-dialog-centered modal-fullscreen-sm-down">
                    <div class="modal-content">
                        <div class="modal-header">
                            <div class="w-100">
                                <h5 class="modal-title mb-1" id="pj_detail_title">Detail Pekerjaan</h5>
                                <div class="d-flex align-items-center justify-content-between gap-2 flex-wrap">
                                    <div class="text-body-secondary" id="pj_detail_tanggal">-</div>
                                    <span class="badge text-bg-secondary" id="pj_detail_status">-</span>
                                </div>
                            </div>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div id="pj_detail_alert" class="alert d-none" role="alert"></div>

                            <div class="list-group list-group-flush">
                                <div class="list-group-item px-0">
                                    <div class="text-uppercase text-body-secondary small">DITUGASKAN</div>
                                    <div class="fw-semibold" id="pj_detail_assigned">-</div>
                                </div>
                                <div class="list-group-item px-0">
                                    <div class="text-uppercase text-body-secondary small">MANAGER</div>
                                    <div class="fw-semibold" id="pj_detail_reporter">-</div>
                                </div>
                                <div class="list-group-item px-0">
                                    <div class="text-uppercase text-body-secondary small">DESKRIPSI</div>
                                    <div id="pj_detail_desc" class="mt-1">-</div>
                                </div>
                                <div class="list-group-item px-0 d-none" id="pj_detail_done_row">
                                    <div class="text-uppercase text-body-secondary small">WAKTU TUGAS SELESAI</div>
                                    <div class="fw-semibold" id="pj_detail_done_at">-</div>
                                </div>
                                <!-- File Upload Section -->
                                <div class="list-group-item px-0 d-none" id="pj_detail_upload_row">
                                    <div class="text-uppercase text-body-secondary small">LAMPIRAN BUKTI (Semua Tipe File, Maks 5MB)</div>
                                    <input type="file" id="pj_detail_file" class="form-control mt-1">

                                    <div id="pj_detail_file_view" class="mt-2 d-none">
                                        <a id="pj_detail_file_link" href="#" target="_blank"
                                            class="btn btn-xs btn-outline-info">Lihat Lampiran Bukti</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-app-secondary" data-bs-dismiss="modal">Tutup</button>
                            <button type="button" class="btn btn-app-primary px-5 d-none" id="pj_detail_done"
                                data-swal-callback="markPekerjaanDone" data-swal-icon="question"
                                data-swal-title="Tandai selesai?"
                                data-swal-text="Status pekerjaan akan diubah menjadi selesai."
                                data-swal-confirm="Ya, selesai" data-swal-cancel="Batal">Tandai Selesai</button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Floating Action Button for Mobile -->
            <button type="button" class="fab-add d-md-none shadow-lg" onclick="window.openPekerjaanModal()"
                title="Tambah Pekerjaan Baru">
                <i class="bi bi-plus-lg"></i>
            </button>

            <script>
                // handle opening modal from calendar and submitting via fetch
                (function () {
                    var modalEl = document.getElementById('pekerjaanModal');
                    var bsModal = null;
                    function ensureModal() {
                        if (!bsModal && window.bootstrap && modalEl) bsModal = new bootstrap.Modal(modalEl);
                        return bsModal;
                    }

                    var detailModalEl = document.getElementById('pekerjaanDetailModal');
                    var bsDetailModal = null;
                    function ensureDetailModal() {
                        if (!bsDetailModal && window.bootstrap && detailModalEl) bsDetailModal = new bootstrap.Modal(detailModalEl);
                        return bsDetailModal;
                    }

                    // Helper untuk escape JS string
                    function escapeJs(str) {
                        return str.replace(/'/g, "\\'").replace(/"/g, '\\"');
                    }

                    // Fungsi Preview Dokumen (Universal)
                    window.viewDocument = function(fileName, title) {
                        const viewerModal = new bootstrap.Modal(document.getElementById('docViewerModal'));
                        const iframe = document.getElementById('docViewerIframe');
                        const titleEl = document.getElementById('docViewerTitle');
                        const downloadBtn = document.getElementById('btnDownloadActual');
                        const loader = document.getElementById('docLoader');

                        const fileUrl = `<?php echo site_url('uploads/'); ?>${fileName}`;
                        const encodedUrl = encodeURIComponent(fileUrl);
                        const ext = fileName.split('.').pop().toLowerCase();
                        
                        titleEl.textContent = `Pratinjau: ${title}`;
                        downloadBtn.href = fileUrl;
                        loader.classList.remove('d-none');
                        iframe.src = ''; // Reset

                        // Logika Router Viewer
                        if (['jpg', 'jpeg', 'png', 'gif', 'webp'].includes(ext)) {
                            iframe.src = fileUrl; // Gambar langsung
                        } else if (ext === 'pdf') {
                            iframe.src = fileUrl; // Browser modern dukung PDF
                        } else if (['xlsx', 'xls', 'doc', 'docx', 'ppt', 'pptx'].includes(ext)) {
                            // Gunakan Google Docs Viewer untuk Office Files
                            iframe.src = `https://docs.google.com/viewer?url=${encodedUrl}&embedded=true`;
                        } else {
                            iframe.src = fileUrl;
                        }

                        viewerModal.show();
                    };

                    window.openPekerjaanDetailModal = function () {
                        ensureDetailModal();
                        if (bsDetailModal) bsDetailModal.show();
                    };

                    // expose helper to calendar dateClick
                    window.openPekerjaanModal = function (dateStr) {
                        ensureModal();
                        var manualEl = document.getElementById('pj_ditugaskan');
                        document.getElementById('pj_mulai').value = dateStr || '';
                        document.getElementById('pj_selesai').value = dateStr || '';
                        if (manualEl) manualEl.value = '';
                        var titleEl = document.getElementById('pj_judul');
                        var descEl = document.getElementById('pj_deskripsi');
                        var periodeEl = document.getElementById('pj_periode');
                        if (titleEl) { titleEl.value = ''; titleEl.readOnly = false; }
                        if (descEl) { descEl.value = ''; descEl.readOnly = false; }
                        if (periodeEl) periodeEl.value = 'harian';

                        if (bsModal) bsModal.show();
                        setTimeout(function () {
                            var el = document.getElementById('pj_judul');
                            if (el) el.focus();
                        }, 300);
                    };

                    // submit handler (called by SweetAlert confirm)
                    window.submitPekerjaan = function () {
                        var form = document.getElementById('pekerjaanForm');

                        // client-side validation: use HTML5 constraint validation
                        if (!form.checkValidity()) {
                            form.reportValidity();
                            return;
                        }
                        var fd = new FormData(form);
                        fetch('<?php echo site_url("api/create_pekerjaan.php"); ?>', { method: 'POST', body: fd, credentials: 'same-origin' })
                            .then(function (res) { return res.json(); })
                            .then(function (json) {
                                if (json && json.success) {
                                    if (bsModal) bsModal.hide();
                                    if (window.Swal) Swal.fire({ icon: 'success', title: 'Tersimpan', text: json.message || 'Pekerjaan tersimpan' });
                                    // refetch events if calendar present
                                    if (window.pekerjaanCalendar && typeof window.pekerjaanCalendar.refetchEvents === 'function') {
                                        window.pekerjaanCalendar.refetchEvents();
                                    } else {
                                        // fallback reload
                                        setTimeout(function () { location.reload(); }, 700);
                                    }
                                } else {
                                    if (window.Swal) Swal.fire({ icon: 'error', title: 'Gagal', text: json.message || 'Gagal menyimpan' });
                                }
                            }).catch(function (err) {
                                console.error(err);
                                if (window.Swal) Swal.fire({ icon: 'error', title: 'Error', text: 'Terjadi error saat menyimpan.' });
                            });
                    };

                    // button: attach swal confirm via helper
                    var saveBtn = document.getElementById('pj_save');
                    if (saveBtn) {
                        saveBtn.dataset.swalCallback = 'submitPekerjaan';
                        saveBtn.dataset.swalIcon = 'question';
                        saveBtn.dataset.swalTitle = 'Simpan pekerjaan?';
                        saveBtn.dataset.swalText = 'Pekerjaan akan disimpan.';
                        saveBtn.dataset.swalConfirm = 'Ya, simpan';
                        saveBtn.dataset.swalCancel = 'Batal';
                    }

                    // No master selection on this page; create is manual/daily

                    // mark done handler (detail modal) - called by SweetAlert confirm
                    window.markPekerjaanDone = function () {
                        var btn = this || document.getElementById('pj_detail_done');
                        if (!btn) return;

                        var isMaster = btn.dataset.isMaster === '1';
                        var id = btn.dataset.id;
                        var masterId = btn.dataset.masterId;
                        var occDate = btn.dataset.occDate;
                        var occToken = btn.dataset.occToken;

                        if (isMaster) {
                            if (!masterId || !occDate || !occToken) return;
                        } else {
                            if (!id) return;
                        }

                        var alertEl = document.getElementById('pj_detail_alert');
                        function showAlert(kind, text) {
                            if (!alertEl) return;
                            alertEl.classList.remove('d-none', 'alert-success', 'alert-danger');
                            alertEl.classList.add(kind === 'success' ? 'alert-success' : 'alert-danger');
                            alertEl.textContent = text;
                        }

                        var fileInput = document.getElementById('pj_detail_file');
                        if (!fileInput || !fileInput.files[0]) {
                            showAlert('danger', 'Mohon pilih file bukti pekerjaan terlebih dahulu.');
                            return;
                        }

                        var file = fileInput.files[0];
                        if (file.size > 5 * 1024 * 1024) { // Maksimal 5MB
                            showAlert('danger', 'Ukuran file terlalu besar. Maksimal 5MB.');
                            return;
                        }

                        var fd = new FormData();
                        if (isMaster) {
                            fd.append('master_tugas_id', masterId);
                            fd.append('tgl_mulai', occDate);
                            fd.append('token', occToken);
                        } else {
                            // Strip prefix 'real-' if exists
                            var cleanId = id ? String(id).replace('real-', '') : id;
                            fd.append('id', cleanId);
                        }
                        fd.append('lampiran', file);

                        btn.disabled = true;
                        fetch('<?php echo site_url("api/mark_done.php"); ?>', {
                            method: 'POST',
                            credentials: 'same-origin',
                            body: fd
                        })
                            .then(function (r) { return r.json(); })
                            .then(function (json) {
                                if (json && json.success) {
                                    showAlert('success', 'Berhasil ditandai selesai.');
                                    var statusEl = document.getElementById('pj_detail_status');
                                    if (statusEl) {
                                        statusEl.textContent = 'done';
                                        statusEl.classList.remove('text-bg-secondary', 'text-bg-primary');
                                        statusEl.classList.add('text-bg-success');
                                    }
                                    btn.classList.add('d-none');
                                    if (window.pekerjaanCalendar) window.pekerjaanCalendar.refetchEvents();
                                } else {
                                    showAlert('error', (json && json.message) ? json.message : 'Gagal memperbarui.');
                                    btn.disabled = false;
                                }
                            })
                            .catch(function (err) {
                                console.error(err);
                                showAlert('error', 'Terjadi kesalahan.');
                                btn.disabled = false;
                            });
                    };
                })();
            </script>

        </div>
    </div>
</div>

<?php
require_once __DIR__ . '/includes/footer.php';

// SweetAlert confirm for click actions
if (function_exists('render_swal_confirm_clicks')) {
    render_swal_confirm_clicks('#pj_save, #pj_detail_done');
}
?>