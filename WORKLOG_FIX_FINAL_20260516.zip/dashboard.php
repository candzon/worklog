<!-- views/dashboard.php -->
<main class="app-main">
  <div class="app-content-header">
    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-6"><h3 class="mb-0">Dashboard</h3></div>
        <div class="col-sm-6"><ol class="breadcrumb float-sm-end"><li class="breadcrumb-item"><a href="#">Home</a></li><li class="breadcrumb-item active">Dashboard</li></ol></div>
      </div>
      
      <div class="app-content">
        <div class="container-fluid">
          
          <?php if (isset($revisiAlertCount) && $revisiAlertCount > 0): ?>
          <!-- Alert Revisi -->
          <div class="alert alert-danger shadow-sm border-0 d-flex align-items-center mb-4" style="border-radius: 12px;" role="alert">
            <i class="bi bi-exclamation-triangle-fill fs-4 me-3"></i>
            <div>
                <strong>Perhatian!</strong> Anda memiliki <strong><?php echo $revisiAlertCount; ?> tugas</strong> yang perlu direvisi/diperbaiki. 
                <a href="<?php echo site_url('daftar_pekerjaan.php'); ?>" class="alert-link text-decoration-underline ms-1">Cek Kalender Pekerjaan</a>.
            </div>
          </div>
          <?php endif; ?>

          <!-- Filter Periode -->
          <div class="card mb-4 shadow-sm border-0" style="border-radius: 12px;">
            <div class="card-body py-3">
              <form action="index.php" method="GET" class="row g-3 align-items-center">
                <div class="col-auto"><label class="fw-bold text-muted small text-uppercase">Filter Periode :</label></div>
                <div class="col-md-2">
                  <select name="bulan" class="form-select form-select-sm">
                    <option value="semua_bulan" <?php echo ($selectedMonth == 'semua_bulan') ? 'selected' : ''; ?>>Semua Bulan</option>
                    <?php 
                    $months = [
                      '01'=>'Januari','02'=>'Februari','03'=>'Maret','04'=>'April','05'=>'Mei','06'=>'Juni',
                      '07'=>'Juli','08'=>'Agustus','09'=>'September','10'=>'Oktober','11'=>'November','12'=>'Desember'
                    ];
                    foreach($months as $mVal => $mName): 
                    ?>
                      <option value="<?php echo $mVal; ?>" <?php echo ($selectedMonth == $mVal) ? 'selected' : ''; ?>><?php echo $mName; ?></option>
                    <?php endforeach; ?>
                  </select>
                </div>
                <div class="col-md-2">
                  <select name="tahun" class="form-select form-select-sm">
                    <?php 
                    $startYear = date('Y') - 2;
                    for($y = $startYear; $y <= date('Y') + 1; $y++): 
                    ?>
                      <option value="<?php echo $y; ?>" <?php echo ($selectedYear == $y) ? 'selected' : ''; ?>><?php echo $y; ?></option>
                    <?php endfor; ?>
                  </select>
                </div>
                <div class="col-md-2">
                  <select name="status_tugas" class="form-select form-select-sm">
                    <option value="semua" <?php echo ($selectedStatus == 'semua') ? 'selected' : ''; ?>>Semua Status</option>
                    <option value="open" <?php echo ($selectedStatus == 'open') ? 'selected' : ''; ?>>Belum Selesai</option>
                    <option value="done" <?php echo ($selectedStatus == 'done') ? 'selected' : ''; ?>>Selesai</option>
                  </select>
                </div>
                <div class="col-auto">
                  <button type="submit" class="btn btn-sm btn-primary px-3"><i class="bi bi-filter me-1"></i> Terapkan</button>
                </div>
              </form>
            </div>
          </div>

          <div class="row mt-3">
            <div class="col-12 mb-3">
              <div class="card shadow-sm border-0" style="border-radius: 12px;">
                <div class="card-header border-0 bg-transparent py-3">
                  <h3 class="card-title fw-bold">
                    <?php echo ($isManager) ? 'Progres Pekerjaan Pegawai' : 'Progres Pekerjaan Saya'; ?>
                    <span class="badge text-bg-light border ms-2 fw-normal" style="font-size: 0.6em;">
                      <?php 
                        if ($selectedMonth === 'semua_bulan') {
                          echo 'Semua Bulan - ' . $selectedYear;
                        } else {
                          echo $months[$selectedMonth] . ' ' . $selectedYear;
                        }
                      ?>
                    </span>
                  </h3>
                </div>
                <div class="card-body table-responsive p-0">
                  <table class="table table-striped table-valign-middle">
                    <thead><tr><th>Pegawai</th><th class="text-center">Total</th><th class="text-center">Open</th><th class="text-center">Selesai</th><th>Progres Pencapaian</th></tr></thead>
                    <tbody>
                      <?php if (empty($userProgress)): ?><tr><td colspan="5" class="text-center text-muted py-5">Tidak ada data untuk periode ini.</td></tr>
                      <?php else: foreach ($userProgress as $up): ?>
                        <tr>
                          <td><?php echo htmlspecialchars($up['nama_emp']); ?><br><small class="text-muted"><?php echo htmlspecialchars($up['npp']); ?></small></td>
                          <td class="text-center fw-bold"><?php echo $up['total']; ?></td>
                          <td class="text-center">
                            <a href="javascript:void(0)" class="badge text-bg-primary btn-detail-task py-2 px-3" data-npp="<?php echo $up['npp']; ?>" data-status="open" data-name="<?php echo htmlspecialchars($up['nama_emp']); ?>" style="font-size: 14px;">
                                <?php echo $up['open']; ?> <i class="bi bi-search ms-1" style="font-size: 0.8em;"></i>
                            </a>
                          </td>
                          <td class="text-center">
                            <a href="javascript:void(0)" class="badge text-bg-success btn-detail-task py-2 px-3" data-npp="<?php echo $up['npp']; ?>" data-status="done" data-name="<?php echo htmlspecialchars($up['nama_emp']); ?>" style="font-size: 14px;">
                                <?php echo $up['selesai']; ?> <i class="bi bi-search ms-1" style="font-size: 0.8em;"></i>
                            </a>
                          </td>
                          <td style="width: 25%; min-width: 150px;"><div class="d-flex align-items-center"><div class="progress flex-grow-1" style="height: 0.625rem; border-radius: 0.3125rem;"><div class="progress-bar bg-success" style="width: <?php echo $up['persen']; ?>%"></div></div><span class="ms-2 fw-bold text-success"><?php echo $up['persen']; ?>%</span></div></td>
                        </tr>
                      <?php endforeach; endif; ?>
                    </tbody>
                  </table>
                </div>
                <?php if ($totalUserProgress > $itemsPerPage): ?><div class="card-footer bg-transparent border-0 py-3"><?php echo render_pagination($totalUserProgress, $itemsPerPage, $currentPage, site_url('index.php'), $_GET); ?></div><?php endif; ?>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="modal fade" id="modalTaskDetail" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered">
      <div class="modal-content border-0 shadow-lg" style="border-radius: 24px;">
        <div class="modal-header border-0 pb-0 px-4 pt-4">
          <div>
            <h5 class="modal-title fw-800 mb-1" style="color: #1e3a8a; font-size: 1.25rem;">Rincian Tugas</h5>
            <p class="text-muted small mb-0">
              <span id="dt_emp_name" class="fw-bold text-primary"></span> • <span id="dt_status_text"></span>
            </p>
          </div>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body p-4">
          <div class="table-responsive" style="border-radius: 16px;">
            <table class="table table-hover align-middle mb-0 custom-task-table">
              <thead>
                <tr>
                  <th class="ps-4 py-3">Tugas & Deskripsi</th>
                  <th class="text-center py-3">Kategori</th>
                  <th class="py-3">Jadwal (Target)</th>
                  <th class="py-3" id="dt_th_upload">Tanggal Upload</th>
                  <th class="text-center py-3" id="dt_th_action">Dokumen</th>
                </tr>
              </thead>
              <tbody id="dt_list_body"></tbody>
            </table>
          </div>
        </div>
        <div class="modal-footer border-0 px-4 pb-4 pt-0 d-flex justify-content-between align-items-center">
          <div id="dt_pagination"></div>
          <button type="button" class="btn btn-light rounded-pill px-4 fw-bold" data-bs-dismiss="modal">Tutup</button>
        </div>
      </div>
    </div>
  <!-- Document Viewer Modal -->
  <div class="modal fade" id="docViewerModal" aria-hidden="true" style="z-index: 2000;">
    <div class="modal-dialog modal-fullscreen">
      <div class="modal-content border-0" style="border-radius: 0;">
        <div class="modal-header bg-dark text-white border-0 py-2">
          <h6 class="modal-title small fw-bold" id="docViewerTitle">Pratinjau Dokumen</h6>
          <div class="d-flex gap-2">
            <a href="#" id="btnDownloadActual" class="btn btn-sm btn-outline-light rounded-pill px-3" target="_blank">
              <i class="bi bi-download me-1"></i> Download
            </a>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
          </div>
        </div>
        <div class="modal-body p-0 bg-secondary d-flex justify-content-center align-items-center">
          <div id="docLoader" class="text-white text-center position-absolute">
            <div class="spinner-border" role="status"></div>
            <div class="mt-2 small">Memuat Dokumen...</div>
          </div>
          <iframe id="docViewerIframe" src="" width="100%" height="100%" style="border:none; background: #fff;" onload="document.getElementById('docLoader').classList.add('d-none')"></iframe>
        </div>
      </div>
    </div>
  </div>
</main>

<style>
  /* Fluid Layout & Flexible Images */
  img { max-width: 100%; height: auto; }
  .app-main { width: 100%; overflow-x: hidden; }
  .container-fluid { width: 100%; padding-right: 1rem; padding-left: 1rem; }
  
  .fw-800 { font-weight: 800; }
  .custom-task-table thead th {
    background: #f8fafc;
    color: #64748b;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 1px;
    border-top: none;
    border-bottom: 2px solid #f1f5f9;
  }
  .task-row { transition: all 0.2s; }
  .task-row:hover { background-color: #f8faff !important; }
  .task-title { color: #1e293b; font-size: 14px; margin-bottom: 2px; }
  .task-desc { font-size: 12px; color: #64748b; line-height: 1.5; }
  .badge-category { 
    font-size: 10px; font-weight: 700; padding: 5px 10px; border-radius: 8px; 
    letter-spacing: 0.5px; background: #f1f5f9; color: #475569;
  }
  /* Period Specific Colors - VIBRANT */
  .badge-harian { background: #dcfce7 !important; color: #15803d !important; border: 1px solid #86efac; }
  .badge-mingguan { background: #fef9c3 !important; color: #a16207 !important; border: 1px solid #fde047; }
  .badge-bulanan { background: #dbeafe !important; color: #1d4ed8 !important; border: 1px solid #93c5fd; }
  .badge-triwulan { background: #ffedd5 !important; color: #c2410c !important; border: 1px solid #fdba74; }
  .badge-manual { background: #f1f5f9 !important; color: #475569 !important; border: 1px solid #cbd5e1; }

  .period-dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    display: inline-block;
    margin-right: 6px;
  }
  .dot-harian { background-color: #22c55e; box-shadow: 0 0 8px rgba(34, 197, 94, 0.4); }
  .dot-mingguan { background-color: #eab308; box-shadow: 0 0 8px rgba(234, 179, 8, 0.4); }
  .dot-bulanan { background-color: #3b82f6; box-shadow: 0 0 8px rgba(59, 130, 246, 0.4); }
  .dot-triwulan { background-color: #f97316; box-shadow: 0 0 8px rgba(249, 115, 22, 0.4); }
  .dot-manual { background-color: #94a3b8; }

  .upload-timestamp { 
    display: inline-flex; align-items: center; gap: 4px; padding: 4px 8px; 
    background: #ecfdf5; color: #059669; border-radius: 6px; font-size: 10px; font-weight: 600;
  }
  .btn-view-doc {
    font-size: 12px; font-weight: 700; border-radius: 10px; padding: 6px 14px;
    transition: all 0.3s; border: 1.5px solid #e2e8f0; color: #475569; background: white;
  }
  .btn-view-doc:hover { background: #3b82f6; color: white; border-color: #3b82f6; box-shadow: 0 4px 12px rgba(59, 130, 246, 0.2); }
  
  .empty-state { padding: 60px 0; text-align: center; }
  .empty-state i { font-size: 3rem; color: #e2e8f0; margin-bottom: 15px; display: block; }
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Nonaktifkan focus trap Bootstrap agar SweetAlert input bisa diketik
    const modal = new bootstrap.Modal(document.getElementById('modalTaskDetail'), {
        focus: false
    });
    const listBody = document.getElementById('dt_list_body');
    const nameEl = document.getElementById('dt_emp_name');
    const statusEl = document.getElementById('dt_status_text');
    const paginationEl = document.getElementById('dt_pagination');
    
    // State untuk track modal saat ini
    let currentModalData = {
        npp: null,
        status: null,
        bulan: null,
        tahun: null,
        page: 1
    };

    // Render table
    function renderTable(tasks) {
      const isDone = currentModalData.status === 'done';
      const cols = isDone ? 5 : 3; // (Info, Kategori, Jadwal) + (Upload, Dokumen if done)

      // Toggle Header Upload
      document.getElementById('dt_th_upload').style.display = isDone ? 'table-cell' : 'none';
      document.getElementById('dt_th_action').style.display = isDone ? 'table-cell' : 'none';

      if (!tasks || tasks.length === 0) {
        listBody.innerHTML = `<tr><td colspan="${cols}">
          <div class="empty-state">
            <i class="bi bi-clipboard-x"></i>
            <h6 class="fw-bold text-secondary">Tidak Ada Data</h6>
            <p class="small text-muted mb-0">Belum ada rincian tugas untuk filter ini.</p>
          </div>
        </td></tr>`;
        return;
      }
        
      let html = '';
      tasks.forEach(t => {
        const dateText = t.tgl_mulai + (t.tgl_selesai && t.tgl_selesai !== t.tgl_mulai ? ` s/d ${t.tgl_selesai}` : '');
        
        let uploadInfo = '<em class="text-muted small">Belum realisasi</em>';
        if (t.updated_at) {
          uploadInfo = `<span class="upload-timestamp" title="Waktu Upload Dokumentasi"><i class="bi bi-clock-history"></i> ${t.updated_at}</span>`;
        }
            
        let actionBtn = '<span class="text-muted" style="font-size: 11px;"><i class="bi bi-info-circle me-1"></i> Tanpa Lampiran</span>';
        if (t.lampiran) {
          actionBtn = `<button type="button" class="btn btn-view-doc me-1" onclick="viewDocument('${t.lampiran}', '${escapeJs(cleanTitle)}')"><i class="bi bi-eye me-1"></i> Lihat Bukti</button>`;
          
          // Tombol Minta Revisi (Hanya Manager & Status Selesai)
          if (isDone && (<?php echo $isManager ? 'true' : 'false'; ?>)) {
            actionBtn += `<button type="button" class="btn btn-sm btn-outline-warning rounded-pill px-3 fw-bold" onclick="requestRevision(${t.id})" title="Minta Perbaikan"><i class="bi bi-exclamation-triangle-fill me-1"></i> Revisi</button>`;
          }
        }

        // Tampilkan catatan revisi jika ada
        let revisionInfo = '';
        if (t.catatan_revisi) {
            revisionInfo = `<div class="mt-2 p-2 border-start border-4 border-warning rounded" style="font-size: 11px; background-color: #fffbeb;">
                <strong class="text-warning"><i class="bi bi-chat-left-text-fill me-1"></i> CATATAN REVISI:</strong><br>
                <span class="text-dark">${t.catatan_revisi}</span>
            </div>`;
        }

        const periodeLower = (t.periode || '').toLowerCase();
        let periodClass = 'badge-manual';
        let dotClass = 'dot-manual';
        
        if (periodeLower === 'harian') { periodClass = 'badge-harian'; dotClass = 'dot-harian'; }
        else if (periodeLower === 'mingguan') { periodClass = 'badge-mingguan'; dotClass = 'dot-mingguan'; }
        else if (periodeLower === 'bulanan') { periodClass = 'badge-bulanan'; dotClass = 'dot-bulanan'; }
        else if (periodeLower === 'triwulan') { periodClass = 'badge-triwulan'; dotClass = 'dot-triwulan'; }

        const typeBadge = `<span class="badge-category ${periodClass}"><span class="period-dot ${dotClass}"></span>${(t.periode || 'MANUAL').toUpperCase()}</span>`;

        const cleanTitle = (t.judul || '').replace(/^\[.*?\]\s*/, '');

        html += `<tr class="task-row">
          <td class="ps-4 py-3" style="max-width: 30rem;">
            <div class="task-title fw-bold">${cleanTitle}</div>
          </td>
          <td class="text-center">${typeBadge}</td>
          <td class="py-3">
            <div class="d-flex align-items-center gap-2">
              <i class="bi bi-calendar3 text-muted" style="font-size: 12px;"></i>
              <span class="fw-semibold text-dark" style="font-size: 13px;">${dateText}</span>
            </div>
          </td>
          ${isDone ? `<td class="py-3">${uploadInfo}</td>` : ''}
          ${isDone ? `<td class="text-center">${actionBtn}</td>` : ''}
        </tr>`;
      });
      listBody.innerHTML = html;
    }
    
    // Render pagination
    function renderPagination(pagination) {
        if (!pagination || pagination.totalPages <= 1) {
            paginationEl.innerHTML = '';
            return;
        }
        
        let html = '<nav aria-label="Task pagination" class="d-flex justify-content-center"><ul class="pagination pagination-sm mb-0">';
        
        // Previous
        if (pagination.page > 1) {
            html += `<li class="page-item"><a class="page-link" href="javascript:void(0)" onclick="loadTaskPage(${pagination.page - 1})" title="Halaman sebelumnya">«</a></li>`;
        } else {
            html += '<li class="page-item disabled"><a class="page-link" href="javascript:void(0)" title="Halaman sebelumnya">«</a></li>';
        }
        
        // Page numbers
        const start = Math.max(1, pagination.page - 2);
        const end = Math.min(pagination.totalPages, start + 4);
        for (let i = start; i <= end; i++) {
            if (i === pagination.page) {
                html += `<li class="page-item active"><a class="page-link" href="javascript:void(0)">${i}</a></li>`;
            } else {
                html += `<li class="page-item"><a class="page-link" href="javascript:void(0)" onclick="loadTaskPage(${i})">${i}</a></li>`;
            }
        }
        
        // Next
        if (pagination.page < pagination.totalPages) {
            html += `<li class="page-item"><a class="page-link" href="javascript:void(0)" onclick="loadTaskPage(${pagination.page + 1})" title="Halaman berikutnya">»</a></li>`;
        } else {
            html += '<li class="page-item disabled"><a class="page-link" href="javascript:void(0)" title="Halaman berikutnya">»</a></li>';
        }
        
        html += '</ul></nav>';
        paginationEl.innerHTML = html;
    }
    
    // Load specific page
    window.loadTaskPage = function(page) {
      currentModalData.page = page;
      const hasAction = currentModalData.status !== 'open';
      const cols = hasAction ? 5 : 4;
      listBody.innerHTML = `<tr><td colspan="${cols}" class="text-center py-5"><div class="spinner-border text-primary" role="status"></div><br><small class="text-muted mt-2 d-block">Memuat data...</small></td></tr>`;
        
        const url = `api/get_ongoing_tasks.php?npp=${currentModalData.npp}&status=${currentModalData.status}&bulan=${currentModalData.bulan}&tahun=${currentModalData.tahun}&page=${page}`;
        
        console.log('Loading tasks:', { url, data: currentModalData, page });
        
        fetch(url)
            .then(r => {
                console.log('Response status:', r.status, 'headers:', r.headers);
                if (!r.ok) {
                    throw new Error(`HTTP ${r.status}: ${r.statusText}`);
                }
                return r.text();
            })
            .then(text => {
                console.log('Raw response text:', text);
                try {
                    return JSON.parse(text);
                } catch(e) {
                    console.error('JSON parse failed:', e);
                    throw new Error('Invalid JSON response: ' + e.message);
                }
            })
            .then(response => {
                console.log('Parsed response:', response);
                if (response && response.data !== undefined && response.pagination !== undefined) {
                    renderTable(response.data);
                    renderPagination(response.pagination);
                } else {
                    console.error('Invalid response structure. Expected data and pagination properties');
                    listBody.innerHTML = '<tr><td colspan="5" class="text-center py-5 text-muted">Tidak ada data rincian untuk ditampilkan.</td></tr>';
                }
            })
            .catch(err => {
                console.error('Full error object:', err);
                console.error('Error message:', err.message);
                console.error('Error stack:', err.stack);
                const errorMsg = err.message || 'Kesalahan tidak diketahui';
                listBody.innerHTML = '<tr><td colspan="5" class="text-center py-5 text-danger"><small><strong>Kesalahan:</strong><br>' + escapeHtml(errorMsg) + '</small></td></tr>';
            });
    };
    
    // Helper untuk escape JS string
    function escapeJs(str) {
        return str.replace(/'/g, "\\'").replace(/"/g, '\\"');
    }

    // Fungsi Preview Dokumen (Universal)
    window.viewDocument = function(fileName, title) {
        const viewerModal = new bootstrap.Modal(document.getElementById('docViewerModal'));
        const iframe = document.getElementById('docViewerIframe');
        const titleEl = document.getElementById('docViewerTitle');
        const downloadBtn = document.getElementById('btnDownloadActual');
        const loader = document.getElementById('docLoader');

        const fileUrl = `<?php echo site_url('uploads/'); ?>${fileName}`;
        const encodedUrl = encodeURIComponent(fileUrl);
        const ext = fileName.split('.').pop().toLowerCase();
        
        titleEl.textContent = `Pratinjau: ${title}`;
        downloadBtn.href = fileUrl;
        loader.classList.remove('d-none');
        iframe.src = ''; // Reset

        // Logika Router Viewer
        if (['jpg', 'jpeg', 'png', 'gif', 'webp'].includes(ext)) {
            iframe.src = fileUrl; // Gambar langsung
        } else if (ext === 'pdf') {
            iframe.src = fileUrl; // Browser modern dukung PDF
        } else if (['xlsx', 'xls', 'doc', 'docx', 'ppt', 'pptx'].includes(ext)) {
            // Gunakan Google Docs Viewer untuk Office Files
            iframe.src = `https://docs.google.com/viewer?url=${encodedUrl}&embedded=true`;
        } else {
            // Fallback: coba buka langsung
            iframe.src = fileUrl;
        }

        viewerModal.show();
    };

    // Helper untuk escape HTML
    function escapeHtml(text) {
        const map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return text.replace(/[&<>"']/g, m => map[m]);
    }

    // Fungsi Request Revision (Hanya untuk Manager)
    window.requestRevision = function(taskId) {
        Swal.fire({
            title: 'Minta Revisi Tugas',
            text: 'Berikan instruksi atau catatan perbaikan untuk pegawai:',
            input: 'textarea',
            inputPlaceholder: 'Contoh: Laporan belum lengkap, mohon tambahkan lampiran nota...',
            inputAttributes: {
                'aria-label': 'Catatan revisi'
            },
            target: document.getElementById('modalTaskDetail'), // Fix focus trap in Bootstrap Modal
            showCancelButton: true,
            confirmButtonText: 'Kirim Instruksi',
            cancelButtonText: 'Batal',
            confirmButtonColor: '#f59e0b',
            showLoaderOnConfirm: true,
            preConfirm: (catatan) => {
                if (!catatan) {
                    Swal.showValidationMessage('Catatan revisi wajib diisi!');
                    return false;
                }
                const fd = new FormData();
                fd.append('id', taskId);
                fd.append('catatan', catatan);

                return fetch('api/request_revision.php', {
                    method: 'POST',
                    body: fd
                })
                .then(response => {
                    if (!response.ok) throw new Error(response.statusText);
                    return response.json();
                })
                .catch(error => {
                    Swal.showValidationMessage(`Request failed: ${error}`);
                });
            },
            allowOutsideClick: () => !Swal.isLoading()
        }).then((result) => {
            if (result.isConfirmed) {
                if (result.value.success) {
                    Swal.fire('Berhasil', result.value.message, 'success');
                    // Refresh modal dan dashboard
                    loadTaskPage(currentModalData.page);
                } else {
                    Swal.fire('Gagal', result.value.message, 'error');
                }
            }
        });
    };

    // Button click handler
    document.querySelectorAll('.btn-detail-task').forEach(btn => {
        btn.addEventListener('click', function() {
            const npp = this.dataset.npp;
            const status = this.dataset.status;
            const empName = this.dataset.name;
            
            // Update state
            currentModalData.npp = npp;
            currentModalData.status = status;
            currentModalData.bulan = '<?php echo $selectedMonth; ?>';
            currentModalData.tahun = '<?php echo $selectedYear; ?>';
            currentModalData.page = 1;
            // Toggle header aksi visibility berdasarkan status
            document.getElementById('dt_th_action').style.display = (status === 'open') ? 'none' : 'table-cell';

            nameEl.textContent = empName;
            statusEl.textContent = (status === 'open' ? 'Tugas Belum Selesai' : 'Tugas Selesai');
            const hasAction = status !== 'open';
            const cols = hasAction ? 5 : 4;
            listBody.innerHTML = `<tr><td colspan="${cols}" class="text-center py-5"><div class="spinner-border text-primary" role="status"></div><br><small class="text-muted mt-2 d-block">Memuat data rincian...</small></td></tr>`;
            modal.show();

            loadTaskPage(1);
        });
    });
});
</script>
