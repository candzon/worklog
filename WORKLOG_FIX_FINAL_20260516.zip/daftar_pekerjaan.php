<?php
/**
 * daftar_pekerjaan.php (Controller & View)
 */
require_once __DIR__ . '/functions/helpers.php';
require_once __DIR__ . '/config/database.php';

ensure_session_started();
require_login();

// Detect Protocol for Base URL (for Google Viewer)
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
$baseUrl = $protocol . $_SERVER['HTTP_HOST'] . rtrim(dirname($_SERVER['PHP_SELF']), '/\\');

$npp = $_SESSION['npp'] ?? null;
$nama_emp = $_SESSION['nama_emp'] ?? null;

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $roleName = function_exists('get_current_role_name') ? get_current_role_name($conn ?? null) : null;
    $isManager = (strtolower((string) $roleName) === 'manager' || strtolower((string) $roleName) === 'admin');
    
    if (!$isManager) {
        $errors[] = 'Hanya role manager yang dapat membuat pekerjaan baru.';
    }

    $judul = trim($_POST['judul'] ?? '');
    $deskripsi = trim($_POST['deskripsi'] ?? '');
    $tglMulai = trim($_POST['tgl_mulai'] ?? '');
    $tglSelesai = trim($_POST['tgl_selesai'] ?? '');
    $assigned_to_npp = trim($_POST['assigned_to_npp'] ?? $_POST['ditugaskan'] ?? '');
    $master_tugas_id = trim($_POST['master_tugas_id'] ?? '');
    $periode = trim($_POST['periode'] ?? '');

    if ($judul === '') $errors[] = 'Judul pekerjaan wajib diisi';
    if ($tglMulai === '') $errors[] = 'Tanggal mulai wajib diisi';
    if ($tglSelesai === '') $errors[] = 'Tanggal selesai wajib diisi';
    if ($assigned_to_npp === '') $errors[] = 'Pilih pegawai yang ditugaskan';

    if (empty($errors) && isset($conn)) {
        $stmt = $conn->prepare("INSERT INTO pekerjaan (judul, deskripsi, created_by_npp, nama_emp, tgl_mulai, tgl_selesai, assigned_to_npp, master_tugas_id, periode) VALUES (?, ?, ?, ?, NULLIF(?, ''), NULLIF(?, ''), ?, NULLIF(?,''), NULLIF(?,''))");
        if ($stmt) {
            $stmt->bind_param('sssssssss', $judul, $deskripsi, $npp, $nama_emp, $tglMulai, $tglSelesai, $assigned_to_npp, $master_tugas_id, $periode);
            $stmt->execute();
            $stmt->close();
            if (function_exists('flash_swal')) flash_swal('success', 'Tersimpan', 'Pekerjaan berhasil ditambahkan');
            header('Location: ' . site_url('daftar_pekerjaan.php'));
            exit;
        } else {
            $errors[] = 'Gagal menyiapkan penyimpanan.';
        }
    }
}

// Fetch employees for selection
$employees = [];
if (isset($conn)) {
    $res = $conn->query("SELECT npp, nama_emp FROM employee ORDER BY nama_emp ASC");
    if ($res) {
        while ($e = $res->fetch_assoc()) $employees[] = $e;
        $res->free();
    }
}

// Render Layout
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>

<!-- Document Viewer Modal -->
<div class="modal fade" id="docViewerModal" tabindex="-1" aria-hidden="true" style="z-index: 2000;">
    <div class="modal-dialog modal-fullscreen">
        <div class="modal-content border-0" style="border-radius: 0;">
            <div class="modal-header bg-dark text-white border-0 py-2">
                <h6 class="modal-title small fw-bold" id="docViewerTitle">Pratinjau Dokumen</h6>
                <div class="d-flex gap-2">
                    <a href="#" id="btnDownloadActual" class="btn btn-sm btn-outline-light rounded-pill px-3" target="_blank">
                        <i class="bi bi-download me-1"></i> Download
                    </a>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
            </div>
            <div class="modal-body p-0 bg-secondary d-flex justify-content-center align-items-center">
                <div id="docLoader" class="text-white text-center position-absolute">
                    <div class="spinner-border" role="status"></div>
                    <div class="mt-2 small">Memuat Dokumen...</div>
                </div>
                <iframe id="docViewerIframe" src="" width="100%" height="100%" style="border:none; background: #fff;" onload="document.getElementById('docLoader').classList.add('d-none')"></iframe>
            </div>
        </div>
    </div>
</div>

<div class="app-main">
    <div class="app-content p-2 p-md-4">
        <div class="container-fluid px-0 px-md-2">
            <h3 class="mb-3 px-2">Pengisian Daftar Pekerjaan</h3>

            <div class="card mb-4 border-0 shadow-sm card-calendar">
                <div class="card-body p-2 p-md-4">
                    <div id="calendar" class="calendar-wrap"></div>
                </div>
            </div>

            <style>
                img { max-width: 100%; height: auto; }
                #calendar { background: #fff; border-radius: 1.25rem; padding: 0.625rem; border: none; }
                .card-calendar { border-radius: 1.5rem; width: 100%; }
                .card-calendar .calendar-wrap { width: 100%; min-height: 56.25rem; }
                .fc .fc-toolbar-title { font-weight: 700; color: #1c1c1e; font-size: 1.8rem !important; }
                .fc .fc-button-primary { background: #f2f2f7; border: none; color: #007aff; border-radius: 0.75rem; padding: 0.625rem 1.25rem; font-weight: 700; font-size: 1rem; transition: all 0.2s; }
                .fc .fc-button-primary:hover { background: #e5e5ea; }
                .fc .fc-button-active { background: #007aff !important; color: #fff !important; }
                .fc .fc-theme-standard td, .fc .fc-theme-standard th { border-color: #f2f2f7; }
                .fc .fc-daygrid-day-number { color: #8e8e93; font-weight: 700; padding: 0.75rem; font-size: 1.1rem; }
                .fc .fc-col-header-cell-cushion { color: #8e8e93; font-size: 0.9rem; text-transform: uppercase; letter-spacing: 0.0625rem; padding: 0.9375rem; font-weight: 700; }
                
                .fc-custom-event {
                    padding: 0.5rem 1rem;
                    border-radius: 2rem; 
                    margin: 0.3rem 0.5rem;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    transition: all 0.2s;
                    cursor: pointer;
                    border-left: 0.5rem solid !important;
                    width: auto !important;
                    min-height: 1.75rem; 
                    box-shadow: 0 0.125rem 0.4rem rgba(0,0,0,0.06);
                }
                .fc-custom-event:hover { filter: brightness(0.94); transform: scale(1.02); box-shadow: 0 0.3rem 0.8rem rgba(0,0,0,0.1); }
                .fc-ce-title { display: none; }

                .ev-harian { background: #e8f5e9 !important; border-color: #4caf50 !important; }
                .ev-mingguan { background: #fffde7 !important; border-color: #fbc02d !important; }
                .ev-bulanan { background: #e3f2fd !important; border-color: #2196f3 !important; }
                .ev-triwulan { background: #fff3e0 !important; border-color: #ff9800 !important; }
                .ev-manual { background: #f5f5f5 !important; border-color: #9e9e9e !important; }
                .ev-revisi { background: #ffebee !important; border-color: #f44336 !important; color: #b71c1c !important; }

                .fc-daygrid-event { background: transparent !important; border: none !important; box-shadow: none !important; }
                .fc-daygrid-event-h-harness { margin-bottom: 0.375rem !important; }
                .fc .fc-daygrid-day-frame { min-height: 11.25rem !important; }
                .modal-content { border-radius: 1.75rem; border: none; box-shadow: 0 1.5625rem 3.125rem -0.75rem rgba(0,0,0,0.2); }
                .modal-header { border-bottom: 0.0625rem solid #f2f2f7; padding: 1.25rem 1.5rem; }
                .modal-footer { border-top: none; padding: 0.75rem 1.5rem 1.5rem; gap: 0.75rem; }
                
                .btn-app-primary { background: linear-gradient(135deg, #007aff 0%, #0056b3 100%); color: #fff; border: none; border-radius: 1rem; padding: 0.875rem 1.75rem; font-weight: 700; transition: all 0.3s; box-shadow: 0 0.25rem 0.75rem rgba(0, 122, 255, 0.3); }
                .btn-app-secondary { background: #f2f2f7; color: #1c1c1e; border: none; border-radius: 1rem; padding: 0.875rem 1.75rem; font-weight: 600; transition: all 0.2s; }
                .btn-app-primary:hover { transform: translateY(-0.125rem); box-shadow: 0 0.375rem 1.25rem rgba(0, 122, 255, 0.4); }
                .btn-app-secondary:hover { background: #e5e5ea; }

                .fab-add {
                    position: fixed; bottom: 1.875rem; right: 1.5625rem; width: 4rem; height: 4rem; border-radius: 50%;
                    background: linear-gradient(135deg, #007aff 0%, #0056b3 100%); color: #fff;
                    display: flex; align-items: center; justify-content: center; font-size: 1.75rem; border: none;
                    box-shadow: 0 0.5rem 1.5625rem rgba(0, 122, 255, 0.5); z-index: 1050;
                    transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
                }
                .fab-add:hover { transform: scale(1.1) rotate(90deg); }

                @media (max-width:575.98px) {
                    .fc .fc-toolbar { flex-direction: column !important; gap: 1rem !important; align-items: center !important; }
                    .fc .fc-toolbar-title { font-size: 1.1rem !important; order: -1; width: 100%; text-align: center; margin: 0 !important; }
                    .fc .fc-toolbar-chunk { display: flex; flex-wrap: wrap; justify-content: center; gap: 0.3rem; width: 100%; }
                    .fc-button { padding: 0.5rem 0.6rem !important; font-size: 0.75rem !important; border-radius: 8px !important; flex: 1 1 auto; }
                    .fc-addPekerjaan-button { display: none !important; }
                    .fc-custom-event { padding: 0.4rem 0.5rem !important; border-radius: 2rem !important; min-height: 1.5rem !important; }
                    .fc .fc-daygrid-day-frame { min-height: 6.25rem !important; }
                    .modal-footer { flex-direction: column-reverse; padding: 1.25rem; }
                    .modal-footer .btn { width: 100%; margin: 0 !important; }
                }
            </style>

            <script>
                var currentUserNpp = '<?php echo e($npp ?? ''); ?>';
                window.addEventListener('load', function () {
                    var el = document.getElementById('calendar');
                    if (!el || !window.FullCalendar) return;

                    var isMobile = window.innerWidth < 576; 
                    var hLeft = isMobile ? 'prev,next today filterRevisi' : 'prev,next today addPekerjaan filterRevisi';
                    var hRight = isMobile ? 'listWeek,dayGridMonth' : 'dayGridMonth,timeGridWeek,listWeek';
                    var initialDate = new Date().toISOString().split('T')[0];

                    // Helper untuk escape JS string
                    function escapeJs(str) {
                        return String(str || '').replace(/'/g, "\\'").replace(/"/g, '\\"');
                    }

                    // Fungsi Preview Dokumen (Universal)
                    window.viewDocument = function(fileName, title) {
                        const viewerModal = new bootstrap.Modal(document.getElementById('docViewerModal'));
                        const iframe = document.getElementById('docViewerIframe');
                        const titleEl = document.getElementById('docViewerTitle');
                        const downloadBtn = document.getElementById('btnDownloadActual');
                        const loader = document.getElementById('docLoader');

                        const fileUrl = `<?php echo site_url('uploads/'); ?>${fileName}`;
                        const encodedUrl = encodeURIComponent(fileUrl);
                        const ext = fileName.split('.').pop().toLowerCase();
                        
                        titleEl.textContent = `Pratinjau: ${title}`;
                        downloadBtn.href = fileUrl;
                        loader.classList.remove('d-none');
                        iframe.src = ''; 

                        if (['jpg', 'jpeg', 'png', 'gif', 'webp'].includes(ext)) {
                            iframe.src = fileUrl;
                        } else if (ext === 'pdf') {
                            iframe.src = fileUrl; 
                        } else if (['xlsx', 'xls', 'doc', 'docx', 'ppt', 'pptx'].includes(ext)) {
                            iframe.src = `https://docs.google.com/viewer?url=${encodedUrl}&embedded=true`;
                        } else {
                            iframe.src = fileUrl;
                        }
                        viewerModal.show();
                    };

                    function showEventDetail(ev) {
                        function escapeHtml(s) {
                            return String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;');
                        }

                        var props = ev.extendedProps || {};
                        var status = props.status || '';
                        var assigned = props.ditugaskan || '';
                        var tglMulai = props.tgl_mulai || ev.startStr || '';
                        var tglSelesai = props.tgl_selesai || '';
                        var tanggalText = tglSelesai ? (tglMulai + ' — ' + tglSelesai) : tglMulai;

                        var titleEl = document.getElementById('pj_detail_title');
                        var tanggalEl = document.getElementById('pj_detail_tanggal');
                        var statusEl = document.getElementById('pj_detail_status');
                        var assignedEl = document.getElementById('pj_detail_assigned');
                        var reporterEl = document.getElementById('pj_detail_reporter');
                        var descEl = document.getElementById('pj_detail_desc');
                        var alertEl = document.getElementById('pj_detail_alert');
                        var doneBtn = document.getElementById('pj_detail_done');

                        var rawTitle = ev.title || '';
                        var cleanTitle = rawTitle.replace(/^\[.*?\]\s*/, '');
                        if (titleEl) titleEl.textContent = cleanTitle;
                        if (tanggalEl) tanggalEl.textContent = tanggalText;

                        if (statusEl) {
                            statusEl.textContent = status ? status : '-';
                            statusEl.className = 'badge ' + (status === 'done' ? 'text-bg-success' : (status === 'revisi' ? 'text-bg-danger' : 'text-bg-primary'));
                        }

                        if (assignedEl) assignedEl.textContent = (props.assigned_name || '') + ' (' + assigned + ')';
                        if (reporterEl) reporterEl.textContent = props.reporter_name || 'Manager';
                        if (descEl) descEl.innerHTML = (props.description || '').replace(/\n/g, '<br>') || '-';

                        if (alertEl) {
                            alertEl.classList.add('d-none');
                            if (status === 'revisi' && props.catatan_revisi) {
                                alertEl.classList.remove('d-none');
                                alertEl.classList.add('alert-danger');
                                alertEl.innerHTML = `<strong>PERLU REVISI:</strong><br>${props.catatan_revisi}`;
                            }
                        }

                        var canDone = currentUserNpp && assigned === currentUserNpp && status !== 'done';
                        if (doneBtn) {
                            doneBtn.dataset.id = ev.id;
                            doneBtn.dataset.isMaster = props.is_master ? '1' : '0';
                            doneBtn.dataset.masterId = props.master_tugas_id || '';
                            doneBtn.dataset.occDate = tglMulai;
                            doneBtn.dataset.occToken = props.occ_token || '';
                            doneBtn.classList.toggle('d-none', !canDone);
                        }

                        var fileInput = document.getElementById('pj_detail_file');
                        var fileView = document.getElementById('pj_detail_file_view');
                        var fileLink = document.getElementById('pj_detail_file_link');
                        var uploadRow = document.getElementById('pj_detail_upload_row');
                        
                        if (uploadRow) {
                            uploadRow.classList.remove('d-none');
                            if (status === 'done') {
                                if (fileInput) fileInput.classList.add('d-none');
                                if (props.lampiran) {
                                    fileView.classList.remove('d-none');
                                    fileLink.innerHTML = 'Lihat Lampiran Bukti';
                                    fileLink.className = 'btn btn-sm btn-outline-info';
                                    fileLink.onclick = (e) => { e.preventDefault(); viewDocument(props.lampiran, cleanTitle); };
                                } else fileView.classList.add('d-none');
                            } else if (status === 'revisi') {
                                if (fileInput) { fileInput.classList.remove('d-none'); fileInput.value = ''; }
                                if (props.lampiran) {
                                    fileView.classList.remove('d-none');
                                    fileLink.innerHTML = '<i class="bi bi-file-earmark-x"></i> Dokumen Sebelumnya (Ditolak)';
                                    fileLink.className = 'btn btn-xs btn-outline-danger mt-2';
                                    fileLink.onclick = (e) => { e.preventDefault(); viewDocument(props.lampiran, cleanTitle); };
                                } else fileView.classList.add('d-none');
                            } else {
                                if (fileInput) { fileInput.classList.remove('d-none'); fileInput.value = ''; }
                                fileView.classList.add('d-none');
                            }
                        }

                        var bsDetailModal = new bootstrap.Modal(document.getElementById('pekerjaanDetailModal'));
                        bsDetailModal.show();
                    }

                    var calendar = new FullCalendar.Calendar(el, {
                        initialView: isMobile ? 'listWeek' : 'dayGridMonth',
                        initialDate: initialDate,
                        customButtons: {
                            addPekerjaan: { text: 'Tambah Pekerjaan', click: function () { window.openPekerjaanModal(); } },
                            filterRevisi: {
                                text: 'Cek Revisi',
                                click: function (e) {
                                    var currentSrc = calendar.getEventSources()[0];
                                    if (!currentSrc) return;
                                    var isRevisiMode = currentSrc.url.includes('status=revisi');
                                    currentSrc.remove();
                                    if (isRevisiMode) {
                                        calendar.changeView(isMobile ? 'listWeek' : 'dayGridMonth');
                                        calendar.addEventSource('<?php echo site_url("api/events_pekerjaan.php"); ?>?status=open');
                                        e.target.style.backgroundColor = ''; e.target.innerHTML = 'Cek Revisi';
                                    } else {
                                        calendar.changeView('listYear');
                                        calendar.addEventSource('<?php echo site_url("api/events_pekerjaan.php"); ?>?status=revisi');
                                        e.target.style.backgroundColor = '#f44336'; e.target.style.color = '#fff'; e.target.innerHTML = 'Kembali';
                                    }
                                }
                            }
                        },
                        headerToolbar: { left: hLeft, center: 'title', right: hRight },
                        events: '<?php echo site_url("api/events_pekerjaan.php"); ?>?status=open',
                        dayMaxEventRows: isMobile ? 2 : 6,
                        locale: 'id',
                        eventClick: function (info) { showEventDetail(info.event); },
                        eventContent: function (arg) {
                            var ev = arg.event;
                            var props = ev.extendedProps || {};
                            var periode = (props.periode || '').toLowerCase();
                            var statusVal = (props.status || '').toLowerCase();
                            var colorClass = 'ev-manual';
                            if (periode === 'harian') colorClass = 'ev-harian';
                            else if (periode === 'mingguan') colorClass = 'ev-mingguan';
                            else if (periode === 'bulanan') colorClass = 'ev-bulanan';
                            else if (periode === 'triwulan') colorClass = 'ev-triwulan';
                            if (statusVal === 'revisi') colorClass = 'ev-revisi';

                            if (isMobile && arg.view.type === 'dayGridMonth') {
                                var dotColor = (statusVal === 'revisi') ? '#f44336' : (periode === 'harian' ? '#4caf50' : (periode === 'bulanan' ? '#2196f3' : '#9e9e9e'));
                                return { html: '<div style="display:flex; justify-content:center; padding: 2px 0;"><div style="width:8px; height:8px; border-radius:50%; background-color:' + dotColor + ';"></div></div>' };
                            }
                            return { html: '<div class="fc-custom-event ' + colorClass + '"></div>' };
                        }
                    });
                    calendar.render();
                    window.pekerjaanCalendar = calendar;
                });

                window.openPekerjaanModal = function (dateStr) {
                    var modalEl = document.getElementById('pekerjaanModal');
                    var bsModal = new bootstrap.Modal(modalEl);
                    document.getElementById('pj_mulai').value = dateStr || '';
                    document.getElementById('pj_selesai').value = dateStr || '';
                    bsModal.show();
                };

                document.getElementById('pj_save').onclick = function() {
                    var form = document.getElementById('pekerjaanForm');
                    if (!form.checkValidity()) { form.reportValidity(); return; }
                    fetch('<?php echo site_url("api/create_pekerjaan.php"); ?>', { method: 'POST', body: new FormData(form) })
                    .then(r => r.json()).then(json => {
                        if (json.success) { location.reload(); }
                    });
                };

                window.markPekerjaanDone = function() {
                    var btn = document.getElementById('pj_detail_done');
                    var fd = new FormData();
                    var id = btn.dataset.id;
                    fd.append('id', id ? id.replace('real-', '') : '');
                    fd.append('lampiran', document.getElementById('pj_detail_file').files[0]);
                    fetch('<?php echo site_url("api/mark_done.php"); ?>', { method: 'POST', body: fd })
                    .then(r => r.json()).then(json => { if(json.success) location.reload(); });
                };
            </script>

            <!-- Modal for creating pekerjaan -->
            <div class="modal fade" id="pekerjaanModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-lg modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Buat Pekerjaan</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <form id="pekerjaanForm">
                                <div class="mb-3"><label class="form-label">Judul</label><input name="judul" class="form-control" required></div>
                                <div class="mb-3"><label class="form-label">Deskripsi</label><textarea name="deskripsi" class="form-control" rows="3"></textarea></div>
                                <div class="mb-3"><label class="form-label">Ditugaskan ke</label>
                                    <select name="assigned_to_npp" class="form-select" required>
                                        <option value="">-- Pilih Pegawai --</option>
                                        <?php foreach ($employees as $emp): ?><option value="<?php echo e($emp['npp']); ?>"><?php echo e($emp['nama_emp']); ?></option><?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="row g-3">
                                    <div class="col-6"><label class="form-label">Mulai</label><input type="date" name="tgl_mulai" id="pj_mulai" class="form-control" required></div>
                                    <div class="col-6"><label class="form-label">Selesai</label><input type="date" name="tgl_selesai" id="pj_selesai" class="form-control" required></div>
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-app-secondary" data-bs-dismiss="modal">Batal</button>
                            <button type="button" id="pj_save" class="btn btn-app-primary px-5">Simpan</button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Modal Detail -->
            <div class="modal fade" id="pekerjaanDetailModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-lg modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <div class="w-100"><h5 class="modal-title mb-1" id="pj_detail_title"></h5><div class="d-flex justify-content-between small"><span id="pj_detail_tanggal"></span><span id="pj_detail_status"></span></div></div>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div id="pj_detail_alert" class="alert d-none"></div>
                            <div class="mb-3"><label class="small text-muted text-uppercase">Pelaksana</label><div id="pj_detail_assigned" class="fw-bold"></div></div>
                            <div class="mb-3"><label class="small text-muted text-uppercase">Manager</label><div id="pj_detail_reporter" class="fw-bold"></div></div>
                            <div class="mb-3"><label class="small text-muted text-uppercase">Deskripsi</label><div id="pj_detail_desc"></div></div>
                            <div id="pj_detail_upload_row" class="mt-3">
                                <label class="form-label">Lampiran Bukti</label>
                                <input type="file" id="pj_detail_file" class="form-control">
                                <div id="pj_detail_file_view" class="mt-2 d-none"><a id="pj_detail_file_link" href="#" class="btn btn-sm btn-outline-info">Lihat File</a></div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-app-secondary" data-bs-dismiss="modal">Tutup</button>
                            <button type="button" class="btn btn-app-primary px-5 d-none" id="pj_detail_done" onclick="markPekerjaanDone()">Tandai Selesai</button>
                        </div>
                    </div>
                </div>
            </div>

            <button type="button" class="fab-add d-md-none shadow-lg" onclick="window.openPekerjaanModal()"><i class="bi bi-plus-lg"></i></button>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
